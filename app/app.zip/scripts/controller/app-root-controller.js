/**
 * Created by Administrator on 2015/8/18.
 */
angular.module(constVar.appName)
    .controller('appRootController', function ($scope) {
    })