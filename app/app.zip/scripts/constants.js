/**
 * Created by Administrator on 2015/6/17.
 */
var constVar={
    appName:'BIMobileLifeService',

    backstageUrl:'http://www.ln.10086.cn/bi/mobilelife/resources',
    //backstageUrl:'http://10.68.32.44:8080/bi/mobilelife/resources',
    dataFileUrl:'http://localhost:8088/resources/data/',

    dataJsonType:'.json',

    api : {
        wx_server : 'http://221.180.166.2/nlj_wx_s'
    }
};