/**
 * Created by Administrator on 2015/6/10.
 */
'use strict';
angular.module(constVar.appName)
    .service('resetDataService',function ($http) {
        return {};
    });